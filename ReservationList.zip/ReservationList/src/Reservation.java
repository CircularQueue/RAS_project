/**
 * Class name: Reservation
 * Class Description: This class makes a reservation with the customer's name 
 * @author Benjamin
 *
 */
public class Reservation {
	
	/**
	 * This is the name of the customer.
	 */
	private String name;
	/**
	 * This is the time for the reservation
	 */
	private String time;
	/**
	 * This is the date for the reservation
	 */
	private String date;
	/**
	 * This is the number of guests for the reservation.
	 */
	private int numGuests;

	/**
	 * This sets the customer's name to the parameters name.
	 * @param name new Name
	 */
	public void setName(String name){
		
	}
	
	/**
	 * This sets the reservation time to the parameters time.
	 * @param time new Time
	 */
	public void setTime(String time){
		
	}
	
	/**
	 * This sets the reservation date to the parameters date.
	 * @param date new Date
	 */
	public void setDate(String date){
		
	}
	
	/**
	 * This sets the number of guests for the reservation to the parameters number of guests
	 * @param numGuests new numGuests
	 */
	public void setNumGuests(int numGuests){
		
	}
	
	/**
	 * This returns the customer's name
	 * @return customer's name
	 */
	public String getName(){
		
	}
	
	/**
	 * This returns the time for the reservation
	 * @return time
	 */
	public String getTime(){
		
	}
	
	/**
	 * This returns the date for the reservation
	 * @return date
	 */
	public String getDate(){
		
	}
	
	/**
	 * This returns the number of guests for the reservation
	 * @return numGuests
	 */
	public int getNumGuests(){
		
	}
	
}

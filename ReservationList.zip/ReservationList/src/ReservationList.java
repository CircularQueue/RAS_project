/**
 * Class name: ReservationList
 * Class Description: This class adds, searches, removes, updates, and views the ReservationList.
 * @author Benjamin
 *
 */
public class ReservationList {
	
	private Reservation[] resList;

	/**
	 * This adds a reservation onto the reservation list
	 */
	public void addReservation(String name, String date, String time, int numGuests){
		
	}
	
	/**
	 * This will search the list for the wanted name and return it
	 * @param name Wanted name
	 * @return reservation
	 */
	public Reservation searchReservation(String name){
		
	}
	
	/**
	 * This will first search for the wanted name in the list then remove it from the list
	 * @param name Wanted name
	 * @return true if the reservation was removed or false if it was not removed
	 */
	public boolean removeReservation(String name){
		
	}
	
	/**
	 * This will first search for the wanted name in the list then update that reservation
	 * @param name Wanted name
	 * @return true if the reservation was updated or false if it was not updated
	 */
	public boolean updateReservation(String name){
		
	}
	
	/**
	 * This will present the entire list
	 * @return the resList
	 */
	public Reservation[] viewList(){
		
	}
	
}
